import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.Map; 
import java.util.List; 
import java.util.ArrayList; 
import java.util.Iterator; 
import java.io.FileReader; 
import java.io.BufferedReader; 
import processing.core.PVector; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class SuperTeemoBros extends PApplet {

//SoundFile musique;

Monde monde;
Clavier clavier;
Images ressources;
int TILE_W = 32, TILE_H = 32;

int niveau = 0, tries = 1;
boolean perdu = false, animationFinNiveau = false, fini = false, start = false;
long debutAnimation, compteur, totalTime, debut;
float score = 0;
String fond;

PFont font, arial;

public void setup()
{
  noStroke();
  
  
  ressources = new Images();
  
  font = createFont("airstrike.ttf", 42);
  arial = createFont("Arial", 24);
  textFont(font);
  
  niveau = 1;
  monde = new Monde(sketchPath() + "/niveau-" + niveau + ".lvl");
  monde.calculerAffichage();
  fond = "fond-" + niveau;
  //musique = new SoundFile(this, "musique-" + niveau + ".mp3");
 // musique.play();
  
  clavier = new Clavier();
  
  debutAnimation = millis();
  debut = millis();
  
  textSize(40);
  textAlign(CENTER, CENTER);
}

public void draw()
{
  background(0);
  
  if (!start)
  {
    fill(255);
    textSize(20);
    textFont(arial);
    text("La bataille des campagnes fait rage, les mêmes et les carottes fusent de toute part. Dans ce chaos, un seul objectif : détruire les listes adverses pour sauver les Legends.", 0, height / 2 - 200, width, 300);
    
    
    textSize(14);
    text("[Flèches] => se déplacer, [Espace] => tirer", width / 2, height / 2 + 125);
    text("Appuyez sur [Entrée] pour commencer", width / 2, height / 2 + 150);
    
    textFont(font);
    
    if (millis() > 5000 && keyCode == ENTER)
       start = true;
    return;
  }
  
  image(ressources.get(fond), map(monde.vue.positionVue.x, 0, monde.w, -200, 0), map(monde.vue.positionVue.y, 0, monde.h, -50, 0), width + 200, height + 50);
  
  if (fini) {
    fill(100, 0, 0, 200);
    rect(0, height / 2 - height / 4, 0, height / 2);
    fill(255);
    textSize(42);
    text("Vous êtes une légende", width / 2, height / 2 - 50);
    textSize(24);
    text("Score : " + (int)score, width / 2, height / 2 + 50);
    return;
  }
  
  
  if (perdu) {
    monde.afficher();
    fill(100, 0, 0, 200);
    rect(0, height / 2 - height / 4, 0, height / 2);
    fill(255);
    textSize(42);
    text("Mission échouée", width / 2, height / 2 - 50);
    textSize(24);
    text("Appuyez sur [Entree] pour réessayer", width / 2, height / 2 + 50);
    if (key == ENTER || key == RETURN)
     {       
      monde = new Monde(sketchPath() + "/niveau-" + niveau  + ".lvl");
      monde.calculerAffichage();
      perdu = false;
     }
     tries++;
     debut = millis();  
    
  }
  else if (animationFinNiveau)
  {
    monde.afficher();
    gererAnimations();
  }
  else {
    
    if (! monde.evoluer())
      chargerNiveau(-1);
    
    if (monde.joueur.pv >0 && monde.boss == null && monde.ennemis.size() == 0 || monde.boss != null && monde.boss.pv <= 0)
      chargerNiveau(niveau + 1);
    
    monde.afficher();
    
    PVector vitesse = monde.joueur.vitesse;
    float depl = 150;
    if (clavier.estAppuye(clavier.DROITE))
        vitesse.x = depl;
    else if (clavier.estAppuye(clavier.GAUCHE))
      vitesse.x = -depl;
    
    if (clavier.estAppuye(clavier.SAUT))
      monde.joueur.sauter();
      
    if (clavier.estAppuye(clavier.TIR))
    {
      monde.joueur.tirer();
    }
    compteur = millis() - debut;
  }
  
  fill(255);
  textSize(16);
  text(nf(compteur / 1000.f, 0, 2), 30, 15);
}

public void gererAnimations() {
   long now = millis();
   long t = now - debutAnimation;
   
   float x = width;
   if (t < 1500)
   {
      x = map(t, 0, 1500, 0, width);
   }
   
   textSize(42);
   fill(200, 200, 0, 200);
   rect(x - width, height / 2 - height / 4, x, height / 2);
   fill(255);
   text("Niveau terminé !", width - x, height / 2 - height / 4, width, height / 4);
   
   if (t >= 1800)
   {
     textSize(24);
     text(monde.ennemisDetruits + " ennemis tués", width / 2, height / 2);
   }
   if (t >= 2500)
     text(monde.objetsDetruits + " objets détruits", width / 2, height / 2 + 45);
   if (t >= 3000)
     text(monde.tirs + " munitions utilisées", width / 2, height / 2 + 90);
     
     
   if (t >= 3300)
   {   
     text("Appuyez sur [Entrée] pour continuer", width / 2, height / 2 + 150);
     if (key == ENTER || key == RETURN)
     {
       animationFinNiveau = false;
       
      totalTime += compteur;
      debut = millis();
      score += 1000 * monde.objetsDetruits + 3000 * monde.ennemisDetruits + 10000;
      
      if (niveau <= 3) {
        monde = new Monde(sketchPath() + "/niveau-" + niveau  + ".lvl");
        monde.calculerAffichage();
        
        fond = "fond-" + niveau;
      }
      else {
        fini = true;
        
        score = score / ((totalTime / 30000) * sqrt(tries));
      }
     }
     
   }
  
}

public void chargerNiveau(int n)
{
  if (n == -1) {
    perdu = true;
    return;
  }
  
  niveau = n;
  animationFinNiveau =true;
  debutAnimation = millis();
}

public void keyPressed()
{
  clavier.keyPressed(keyCode);
}

public void keyReleased()
{
  clavier.keyReleased(keyCode);
}


class AnimationRect{
  public int x, y, w, h;
  public Animation animation;
  
  public AnimationRect(Animation a, int x, int y, int w, int h)
  {
    this.animation = a;
    this.x = x;
    this.y = y;
    this.w = w;
    this.h = h;
  }
  
  public void afficher()
  {
    image(animation.getFrame(), x, y, w, h);
  }
}

class Animation{

  private ArrayList<PImage> frames;
  private int index, delay;
  private long lastTime;
  private boolean paused;
  public boolean wasReset;
  
  Animation(ArrayList<PImage> _frames, int FPS)
  {
    frames= new ArrayList<PImage>(_frames);
    delay = 1000 / FPS;
    paused = true;
  }
  
  Animation(Tileset tileset, int begin, int end, int FPS)
  {
    frames=new ArrayList<PImage>();
    for (int i=begin; i<=end; i++)
      frames.add(tileset.get(i));
    delay=1000/FPS;
    paused=true;
  }

 public PImage getFrame()
 {
   wasReset = false;
   long now = millis();
   if (paused)
    {
      index=0;
      lastTime=now;
      paused=false;
    }
  
   if (now-lastTime>delay)
   {
     int prevIndex = index;
     index += (now - lastTime) / delay;
     index %= frames.size();
     wasReset = index < prevIndex;
     lastTime=now;
    }
     return frames.get(index);
  }

  public int width()
  {
    return frames.get(index).width;
  }
  
  public int height()
  {
    return frames.get(index).height;
  }

  public void resize(int w, int h)
  {
    for (PImage f: frames)
      f.resize(w,h);
  }

   //Pause it and resume it on next call to show()
   public void pause()
   {
     paused=true;
   }
}

class AnimationSet{
  private ArrayList<Animation> anims=new ArrayList<Animation>();
  private int current=0;
  private List<Integer> queue;
  
  AnimationSet(ArrayList<Animation> _anims) throws IllegalArgumentException
  {
     anims = new ArrayList<Animation>(_anims);
     queue = new ArrayList<Integer>();
  }
  
   AnimationSet(Tileset tileset,int FPS, int offset)
  {
    int w=tileset.getTileX();
    for (int i=0; i < tileset.getTileY(); i++)
    {
      int index = i + offset;
      anims.add(new Animation(tileset,index*w,(index+1)*w-1,FPS));
    }
     queue = new ArrayList<Integer>();
    current=0;
  }
  
  public void queue(int key)
  {
    queue.add(key);
  }
  
  public void add(Animation anim)
  {
  		anims.add(anim);
  }
  
  public PImage getFrame()
  {    
    anims.get(current).paused = false;
    PImage img = anims.get(current).getFrame();
    
    if (anims.get(current).wasReset && queue.size() > 0)
    {
      current = queue.get(0);
      queue.remove(0);
      img = anims.get(current).getFrame();
    }
    return img;
  }
  
  public int width()
  {
    return anims.get(current).width();
  }
  
  public int height()
  {
    return anims.get(current).height();
  }
  
  public void resize(int w, int h)
  {
    for (Animation a: anims)
       a.resize(w,h);
  }
  
  public void change(int key)
  {
    	if (key >=0 && key < current) {
        anims.get(current).pause();
        current = key;
    }
  }
}
class Arme {

  public float cadenceTir;
  public boolean estDistance;
  public int degats;
  public long lastAttaque;
  public Objet owner;
  
  public Arme(Objet o, float cadenceTir, boolean estDistance, int degats) {
    this.cadenceTir = cadenceTir;
    this.estDistance = estDistance;
    this.degats = degats;
    this.owner = o;
  }
  
  protected void tirer(PVector position){
    position.add(owner.regardeDroite ? 10 : -10, 0);
    PVector vitesse = new PVector(owner.regardeDroite ? 500 : -500, 0);
    Projectile proj = new Projectile(position, vitesse, owner);
    proj.degats = degats;
    
    monde.ajouterProjectile(proj);
  }
  
  public void utiliser()
  {
    long now = millis();
    if (now - lastAttaque < 1000 / cadenceTir)
      return;
    
    PVector position = owner.forme.getCenter();
    if (estDistance) {
      tirer(position);
    }
    else {
      position.add(owner.regardeDroite ? TILE_W : -TILE_W, 0);
      Projectile proj = new Projectile(position, new PVector(), owner);
      proj.degats = degats;
      
      Objet o = monde.checkCollision(proj);
      
      if (o != null)
        o.traiterCollision(proj);
      
    }
    lastAttaque = now;
  }
}

class PistoletFocus extends Arme {

  public PistoletFocus(Objet owner) {
    super(owner, .5f, true, 20);
  }
  
  protected void tirer(PVector position) {
    position.add(owner.regardeDroite ? 10 : -10, 0);
    PVector vitesse = PVector.sub(monde.joueur.position, position).setMag(350);
    Projectile proj = new Projectile(position, vitesse, owner);
    proj.degats = degats;
    monde.ajouterProjectile(proj);
  }
    

}

class Shotgun extends Arme {
  public Shotgun(Objet owner){
    super(owner, 1, true, 15);
  }
  
   protected void tirer(PVector position) {
    position.add(owner.regardeDroite ? 10 : -10, 0);
    PVector vitesse = new PVector(owner.regardeDroite ? 500 : -500, 0);
    
    for (int i = -2; i <= 2; i++)
    {
      PVector vitesseProj = new PVector(vitesse.x, vitesse.y).rotate(PI/ 22 * i);
      Projectile proj = new Projectile(position, vitesseProj, owner);
      proj.degats = degats;
      proj.distance = 300;
      monde.ajouterProjectile(proj);
    }
  }
}

class Pistolet extends Arme{
  public Pistolet(Objet owner){
    super(owner, 1, true, 20);
  }
}

class LanceGrenade extends Arme{
  public LanceGrenade(Objet owner){
    super(owner, .3f, true, 100);
  }
  
  protected void tirer(PVector position) {
    int mult = owner.regardeDroite ? 1 : -1;
    position.add(mult * 10, 0);
    PVector vitesse = new PVector(mult * 100 , -600);
    
    if (monde.joueur == owner)
      vitesse.set(vitesse.x * 0.6f, vitesse.y * 0.8f);
    
    for (int i = 0; i < 3; i++)
    {
      PVector vitesseProj = new PVector(vitesse.x, vitesse.y).rotate(mult * PI / 32 * i);
      Grenade proj = new Grenade(position, vitesseProj, owner);
      proj.degats = degats;
      monde.ajouterProjectile(proj);
    }
  }
}

class Mitraillette extends Arme {
  public Mitraillette(Objet owner){
    super(owner, 4, true, 15);
  }
  
  
   protected void tirer(PVector position) {
    position.add(owner.regardeDroite ? 10 : -10, 0);
    PVector vitesse = new PVector(owner.regardeDroite ? 500 : -500, 0);
    PVector vitesseProj = new PVector(vitesse.x, vitesse.y).rotate(PI / 32 * random(-1, 1));
    Projectile proj = new Projectile(position, vitesseProj, owner);
    proj.degats = degats;
    monde.ajouterProjectile(proj);
  }
}

class Couteau extends Arme {
  public Couteau(Objet owner){
    super(owner, 2, false, 20);
  }
}

public class Cercle extends Forme {
	
	PVector pos;
	float r;
	
	public Cercle(PVector p, float rayon)
	{
		pos = p;
		r = rayon;
	}

	public @Override
	boolean collision(Rectangle rect) {
		PVector coords = null;
		//On check si on est dans un des angles
		if (pos.x < rect.pos.x && pos.y < rect.pos.y) //Angle superieur gauche
			coords = rect.pos; //Point superieur gauche
		else if (pos.x < rect.pos.x && pos.y > rect.pos.y + rect.h)
			coords = PVector.add(rect.pos, new PVector(0, rect.h)); // Point inferieur gauche
		else if (pos.x > rect.pos.x + rect.w && pos.y < rect.pos.y)
			coords = PVector.add(rect.pos, new PVector(rect.w, 0)); //Point superieur droit
		else if (pos.x > rect.pos.x + rect.w && pos.y > rect.pos.y + rect.h)
			coords = PVector.add(rect.pos, new PVector(rect.w, rect.h)); //Point inferieur droit
		
		//Si on est dans un des 4 angles
		if (coords != null)
		{
			//On cree un cercle representant le point
			Cercle c = new Cercle(coords, 0);
			return collision(c);
		}
		else //Collision de rectangles
		{
			Rectangle moi = new Rectangle(PVector.sub(pos, new PVector(r, r)), r * 2, r * 2);
			return moi.collision(rect);
		}
	}

	public @Override
	boolean collision(Cercle c) {
		float distSq = PVector.sub(pos, c.pos).magSq();
		float rayons = c.r + r;
		return distSq <= rayons * rayons;
	}

	public @Override
	boolean collision(Point p) {
		PVector dist = p.getCenter();
		return dist.sub(pos).magSq() <= r * r;
	}

	@Override
	public PVector getCenter() {
		return pos.copy();
	}
	
	@Override
	public PVector getNearest(float x, float y)
	{
		PVector vec = new PVector(x, y);
		vec.sub(pos);
		vec.setMag(r);
		
		return PVector.add(pos,  vec);
	}

	@Override
	public Forme getTranslation(PVector dir) {
		return new Cercle(PVector.add(pos, dir), r);
	}


}
public class Clavier {
  
  /**
   * Etats des differentes touches
   */
  private boolean[] touches;
  
  public final int DROITE = 1;
  public final int GAUCHE = 2;
  public final int SAUT = 3;
  public final int TIR = 4;
  public final int MAX = 5;
  
  public Clavier()
  {
    touches = new boolean[MAX];
  }

  public void keyPressed(int keycode)
  {
    setValue(keycode, true);
  }
  
  public void keyReleased(int keycode)
  {
    setValue(keycode, false);
  }
  
  private void setValue(int keycode, boolean val)
  { 
    if (keycode == RIGHT) touches[DROITE] = val;
    else if (keycode == LEFT) touches[GAUCHE] = val;
    else if (keycode == UP) touches[SAUT] = val;
    else if (keycode == ' ') touches[TIR] = val;
  }
  
  public boolean estAppuye(int touche) {
    return touche >= 0 && touche < MAX && touches[touche];
  }
}
class Ennemi extends Objet {

  public PVector[] patrouille;
  public int pointPatrouilleCourant;
  
  public Ennemi(int x, int y)
  {
    super(x, y);
    patrouille = new PVector[2];
    patrouille[0] = new PVector(max(x - 300, 0), y);
    patrouille[1] = new PVector(x + 50, y);
    pointPatrouilleCourant = 0;
    animationSet = new AnimationSet(ressources.tileset("ennemi"), 4, 0);
    arme = new Pistolet(this);
    arme.cadenceTir = 0.3f;
  }
  
  public void evoluerObjet(float duree)
  {
    super.evoluer(duree);
  }
  
  public void evoluer(float duree)
  {
    evoluer(duree, true, true);
  }
  
  public void evoluer(float duree, boolean bouger, boolean tirer)
  {
    PVector dest;
    if (monde.joueur.distanceSq(this) > 80000 || abs(monde.joueur.position.y - position.y) > TILE_H * 3)
    {
      dest = patrouille[pointPatrouilleCourant];
      if (PVector.sub(dest, position).magSq() < 8000)
        pointPatrouilleCourant = (pointPatrouilleCourant + 1) % patrouille.length;
    }
    else
    {
      dest = monde.joueur.position;
      if (tirer && abs(monde.joueur.position.y - position.y) < imageHeight * 1.2f && (!bouger || monde.joueur.distanceSq(this) < 50000))
        tirer();
    }
    if (bouger && PVector.sub(monde.joueur.position, position).add(TILE_W / 2, TILE_H / 2).magSq() > 4 * TILE_W * TILE_W)
      vitesse.x = constrain(dest.x - position.x, -120, 120);
    else vitesse.x = (dest.x - position.x) / 1000.0f;
    
    if ((vitesse.x > 0 && objetsContact[DROITE] != null) || 
        (vitesse.x < 0 && objetsContact[GAUCHE] != null)) 
      sauter();
    super.evoluer(duree);
  }
  
  public boolean isPerso()
  {
    return true;
  }
}

class Dougie extends Ennemi {
  
  public Dougie(int x, int y)
  {
    super(x, y);
    animationSet = new AnimationSet(ressources.tileset("dougie"), 1, 0);
    pv = 2;
  }
  
  public void evoluer(float duree)
  {
    PVector dest= monde.joueur.position;
      
    vitesse.x = dest.x > position.x ? 140 : -140;
    
    if ((vitesse.x > 0 && objetsContact[DROITE] != null && objetsContact[DROITE] != monde.joueur) || 
        (vitesse.x < 0 && objetsContact[GAUCHE] != null && objetsContact[GAUCHE] != monde.joueur)) 
      sauter();
    if (monde.joueur.forme.getCenter().dist(forme.getCenter()) < TILE_W + 5)
      exploser();
    evoluerObjet(duree);
  }
  
  public void traiterCollision(Objet o)
  {
    if (o == monde.joueur)
    {
      o.pv -= 30;
      pv = 0;
      exploser();
    }
  }
}


class Boss extends Ennemi {
  
  public String nom;
  public int pvmax;
  
  public Boss(int x, int y, String nom)
  {
    super(x, y);
    this.pv = pvmax = 220;
    this.nom = nom;
    this.degats = 5;
  }
}

class BossStan extends Boss {
  private long lastMove, lastDougie, lastStan;
  private PVector dest;
  
  public BossStan(int x, int y)
  {
    super(x, y, "Stan");
    this.pv = pvmax = 200;
    dest = new PVector(x,y);
    arme = new PistoletFocus(this);
    
    animationSet = new AnimationSet(ressources.tileset("stan"), 4, 0);
    imageWidth = TILE_W  * 3;
    imageHeight = TILE_H * 3;
    forme = new Rectangle(position, TILE_W - 1, TILE_H * 3 - 1);
    imageX = -TILE_W + 3;
  }
  
  public void evoluer(float duree)
  {
    if (monde.joueur.position.dist(position) < 500)
    {
      long now = millis();
      int phase = (int) map(pv, 250, 0, 0, 3);
      switch(phase)
      {
        case 3:
        case 2:
          if (now - lastStan > 5000)
          {
            Ennemi ennemi = new Ennemi((int) monde.joueur.position.x - 300, (int) monde.joueur.position.y);
            if (monde.checkCollision(ennemi) == null)
              monde.ennemis.add(ennemi);
            lastStan = now;
          }
        case 1 :
          if (now - lastDougie > 5000)
          {
            monde.ennemis.add(new Dougie((int) monde.joueur.position.x - (random(1) > .5f ? 300 : -300), 20));
            lastDougie = now;
          }
        case 0:
          if (now - lastMove > 2000)
          {
            lastMove = now;
            dest = PVector.add(monde.joueur.position, new PVector(0, -250).rotate(random( -PI/2, PI/2)));
          }
          arme.utiliser();
          break;
      }
    }
    
    vitesse = PVector.sub(dest, position).setMag(80);
    evoluerObjet(duree);
  }
}

class BossBreak extends Boss {
  public BossBreak(int x, int y)
  {
    super(x, y, "Break");
    animationSet = new AnimationSet(ressources.tileset("break"), 8, 0);
    imageWidth = TILE_W  * 3;
    imageHeight = TILE_H * 3;
    forme = new Rectangle(position, TILE_W - 1, TILE_H * 3 - 1);
    imageX = -TILE_W + 3;
    arme = new LanceGrenade(this);
  }
}

class BossColt extends Boss {
  
  public boolean tirer;
  public long last; 
  
  public BossColt(int x, int y)
  {
    super(x, y, "Colt");
    animationSet = new AnimationSet(ressources.tileset("colt"), 2, 0);
    imageWidth = TILE_W  * 2;
    imageHeight = TILE_H * 2;
    forme = new Rectangle(position, TILE_W * 2 - 1, TILE_H * 2 - 1);
    arme = new Shotgun(this);
    last = 0;
    
    this.pv = pvmax = 500;
  }
  
  public void evoluer(float duree)
  {
    if (pv < 250)
      arme = new Mitraillette(this);
    if (millis() - last > (tirer ? 3000 : 5000))
    {
      tirer = !tirer;
      last = millis();
    }
    super.evoluer(duree, false, tirer);
  }
  
}

public abstract class Forme{
		
	public boolean collision(Forme f) {
		if (f instanceof Rectangle)
			return collision((Rectangle) f);
		else if (f instanceof Cercle)
			return collision((Cercle) f);
		else if (f instanceof Point)
			return collision((Point) f);
		else
			return false;
	}
	
	public PVector getResponseForce(Forme f)
	{
		PVector force = getCenter();
		force.sub(f.getNearest(force.x, force.y));
		return force.normalize();
	}
	
	public abstract PVector getCenter();
	public abstract PVector getNearest(float x, float y);
	public abstract Forme getTranslation(PVector dir);

	//Package private
	public abstract boolean collision(Rectangle r);
	public abstract boolean collision(Cercle c);
	public abstract boolean collision(Point p);
}


class Images {
  private String noms[] = {"ennemi", "terrain", "default", "joueur", "tir", "break", "explosion", "erlenmeier", "colt", "fond-1", "fond-2", "fond-3", "dougie", "flechette", "stan"};
  private String fichiers[] = {"ennemi.png", "generic-platformer-tiles.png", "boite.png", "teemo.png", "flamme.png", "break.png", "explosion.png", "erlenmeier.png", "colt.png", "desert.jpg", "western.jpg", "espace.png", "dougie.png", "flechette.png", "ironman.png"};
  private String nomsTilesets[] = {"ennemi", "terrain", "joueur", "break", "explosion", "colt", "dougie", "stan"};
  private int taillesTilesets[][] = { {2, 4}, {12, 8}, {4, 4}, {4, 4}, {9, 9}, {4, 4}, {1, 1}, {2, 4}};
  private Map<String, PImage> images;
  private Map<String, Tileset> tilesets;
  
  public Images()
  {
    images = new HashMap<String, PImage>();
    tilesets= new HashMap<String, Tileset>();
    
    for (int i = 0; i < noms.length; i++)
      images.put(noms[i], loadImage(fichiers[i]));
    for (int i = 0; i < nomsTilesets.length; i++)
      tilesets.put(nomsTilesets[i], new Tileset(get(nomsTilesets[i]), taillesTilesets[i][0], taillesTilesets[i][1]));
  }
  
  public PImage get(String nom)
  {
    return images.get(nom);
  }
  
  public Tileset tileset(String nom)
  {
    return tilesets.get(nom);
  }
}
class Joueur extends Objet {
  
  public Joueur(int x, int y)
  {
    super(x, y);
    animationSet = new AnimationSet(ressources.tileset("joueur"), 6, 0);
     this.pv = 100;
    if (niveau == 1) {
      arme = new Pistolet(this);
      arme.cadenceTir = 1.5f;
    }
    else if (niveau == 2)
    {
      arme = new LanceGrenade(this);
      arme.cadenceTir = .8f;
    }
    else if (niveau == 3)
    {
      arme = new Mitraillette(this);
    }
  }

  public void evoluer(float duree)
  {
    super.evoluer(duree);
    
    //Friction
    if (objetsContact[BAS] != null)
    {
      vitesse.x *= 0.5f;
    }
    
  }
  
  public boolean isPerso()
  {
    return true;
  }
}







class Monde {

  public int w, h;
  public Joueur joueur;
  public Boss boss;
  public List<Ennemi> ennemis;
  public List<Objet> objets;
  public List<Projectile> projectiles;
  public List<AnimationRect> animations;
  public long lastTime;
  public Vue vue;
  public PVector gravite;
  public int objetsDetruits, ennemisDetruits, tirs;
  
  public Monde(int w, int h)
  {
    init(w, h);
     for (int x = 0; x < w; x++)
      objets.add(new Plateforme(x, h - 1));
      
    
     for (int x = 0; x < 5; x++)
      objets.add(new Ennemi(x * 100, 50));
  }
  
  public Monde(String fichier) 
  {
    load(fichier);
  }
  
  private void calculerAffichage()
  {
    for (Objet o : objets)
    {
      if (o instanceof Plateforme)
        ((Plateforme) o).calculerAffichage();
    }
  }
  
  private void init(int w, int h)
  {
    this.w = w;
    this.h = h;
    
    this.joueur = new Joueur(1, h / 2);
    ennemis = new ArrayList<Ennemi>();
    objets = new ArrayList<Objet>();
    projectiles = new ArrayList<Projectile>();
    animations = new ArrayList<AnimationRect>();
    
    vue = new Vue(joueur.position, width / TILE_W, height / TILE_H, w, h);
    
    gravite = new PVector(0, 350);
  }
  
  private void loadObjet(int x, int y, String[] tokens)
  {
    switch(tokens[0]) {
           case "O":
             objets.add(new Objet(x, y, Boolean.parseBoolean(tokens[3]),  Boolean.parseBoolean(tokens[4]), Integer.parseInt(tokens[5]), Integer.parseInt(tokens[6])));
             break;
           case "J":
             joueur.position.set(x, y);
             break;
           case "E":
             ennemis.add(new Ennemi(x, y));
             break;
           case "P":
             objets.add(new Plateforme(x, y));
             break;
           case "I":
             Plateforme p = new Plateforme(x, y);
             p.est_destructible = false;
             objets.add(p);
             break;
           case "BossStan":
             boss = new BossStan(x, y);
             break;
           case "BossBreak":
             boss = new BossBreak(x, y);
             break;
           case "BossColt":
             boss = new BossColt(x, y);
             break;
       }
  }
  
  public void load(String fichier) {
      BufferedReader stream = null;
    try {
       stream = new BufferedReader(new FileReader(fichier));
       
       String ligne = stream.readLine();
       
       while ((ligne.length() == 0 || ligne.charAt(0) == '#'))
         ligne = stream.readLine();
         
       String[] coords = ligne.split(" ");
       init(Integer.parseInt(coords[0]), Integer.parseInt(coords[1]));
       
       while ((ligne = stream.readLine()) != null)
       {
         ligne = ligne.trim();
         if (ligne.length() == 0 || ligne.charAt(0) == '#')
           continue;
           
         String[] tokens = ligne.split(" ");
         Range xRange = new Range(tokens[1]);
         Range yRange = new Range(tokens[2]);
                  
         for (int x : xRange)
           for (int y : yRange)
             loadObjet(x, y, tokens);;
       }
         
       stream.close();
    } catch (IOException e) {
      System.err.println(e);
      exit();
    }
  }
  
  private void enleverMorts(List<? extends Objet> objets)
  {
    Iterator<? extends Objet> i = objets.iterator();
 
    while(i.hasNext()) {
        Objet o = i.next();
        if (o.pv <= 0 || o.position.y > h * TILE_H + 100) {
            i.remove();
            if (!o.isPerso() && o.est_mobile && !(o instanceof Projectile))
              objetsDetruits++;
            if (o.isPerso())
              ennemisDetruits++;
        }
    }    
  }
  
  public boolean evoluer()
  {
    if (lastTime == 0) lastTime = millis();
    long now = millis();
    float duree = (now - lastTime) / 1000.0f;
    
    joueur.evoluer(duree);
    
    if (boss != null)
      boss.evoluer(duree);
    
    for (Ennemi e : ennemis)
      e.evoluer(duree);
    
    for (Objet o : objets)
      o.evoluer(duree);
      
    for (Projectile p : projectiles)
      p.evoluer(duree);
      
    lastTime = now;
    
    //Eliminer trucs morts et hors screen
    enleverMorts(ennemis);
    enleverMorts(objets);
    enleverMorts(projectiles);
    
    return joueur.pv > 0 && joueur.position.y <= h * TILE_H + 100;
  }
  
  public Objet checkCollision(Objet obj)
  {
    return checkCollision(obj, null);
  }

  public Objet checkCollision(Objet obj, Objet aIgnorer)
  {
    for (Objet o: objets)
    {
      if (obj != o && aIgnorer != o && o.affecte(obj) && o.pv >0 && o.checkCollision(obj))
        return o;
    }
    
    for (Projectile p : projectiles)
    {
      if (obj != p && aIgnorer != p && p.affecte(obj) && p.pv > 0 && p.checkCollision(obj))
        return p;
    }

    for (Ennemi e: ennemis)
    {
      if (obj != e && aIgnorer != e && e.affecte(obj) && e.pv > 0 && e.checkCollision(obj))
        return e;
    }
    if (obj != joueur && aIgnorer != joueur && joueur.affecte(obj) && joueur.pv > 0 && joueur.checkCollision(obj))
      return joueur;
    
    if (obj != boss && aIgnorer != boss && boss != null && boss.pv > 0 && boss.affecte(obj) && boss.checkCollision(obj))
      return boss;
    return null;
  }
  
  public void ajouterProjectile(Projectile p)
  {
    if (checkCollision(p, p.tireur) == null)
    {
      if (p.tireur == monde.joueur)
        tirs++;
      projectiles.add(p);
    }
  }
  
  
  public void afficher()
  {
    vue.actualiser();
    PVector posVuePixels = vue.getPosVuePixels();
    
    pushMatrix();
    translate(-posVuePixels.x, -posVuePixels.y);
    
    for (Objet o : objets)
      if (vue.estDansVue(o))
        o.afficher();
        
    for (Projectile p : projectiles)
      if (vue.estDansVue(p))
        p.afficher();
    
    for (Ennemi e : ennemis)
      if (vue.estDansVue(e))
        e.afficher();
    
    if (vue.estDansVue(joueur) && joueur.pv > 0)
      joueur.afficher();
      
    if (boss != null && vue.estDansVue(boss) && boss.pv > 0)
      boss.afficher();
      
    Iterator<AnimationRect> i = animations.iterator();
    while(i.hasNext()) {
        AnimationRect a = i.next();
        a.animation.getFrame(); // trigger wasReset
        if (a.animation.wasReset) {
            i.remove();
        }
    }
    
    for (AnimationRect a : animations)
      a.afficher();
      
    popMatrix();

    dessinerBarreDeVie(joueur.pv, 100, 10, height - 25, 100, 20);
    
    if (boss != null && vue.estDansVue(boss))
    {
       textSize(24);
       text(boss.nom, width - 300, height - 15);
       dessinerBarreDeVie(monde.boss.pv, monde.boss.pvmax, width - 230, height - 25, 200, 20);
    }
  }
  
  private void dessinerBarreDeVie(float pvs, float max, float x, float y, float wBar, float hBar)
  {
    
    pvs = constrain(pvs, 0, max);
    
    stroke(0);
    strokeWeight(3);
    fill(200, 50, 50);
    
    pushMatrix();
    translate(x, y);
    beginShape();
    vertex(9, -1);
    vertex(wBar + 11, -1);
    vertex(wBar + 1, hBar + 1);
    vertex(-1, hBar + 1);    
    endShape(CLOSE);
    
    float vie = wBar * (pvs / max);
    noStroke();
    fill(50, 200, 50);
    
    beginShape();
    vertex(10, 0);
    vertex(vie + 10, 0);
    vertex(vie, hBar);
    vertex(0, hBar);    
    endShape(CLOSE);
    
    fill(0);
    
    textSize(14);
    text(((int) pvs) + "  PV", wBar / 2 + 5, hBar / 2 - 2);
    
    noStroke();
    popMatrix();
  }
  

}
class Objet {
  
  public final static int HAUT = 0, BAS = 1, GAUCHE = 2, DROITE = 3;

  public PVector position, vitesse, acceleration;
  public boolean est_mobile, est_destructible;
  public int pv, degats;
  public Forme forme;
  public boolean regardeDroite;
  public Objet[] objetsContact;
  public Arme arme;
  public AnimationSet animationSet;
  public int imageWidth, imageHeight, imageX;
  
  public Objet(int x, int y) 
  {
    this(x, y, true, true, 20, 0);
  }
  
  public Objet(int x, int y, boolean mobile, boolean destructible, int pv, int degats)
  {
    position = new PVector(x, y);
    vitesse = new PVector(0, 0);
    acceleration = new PVector(0, 0);
    est_mobile = mobile;
    est_destructible = destructible;
    this.pv = pv;
    this.degats = degats;
    objetsContact = new Objet[4];
    forme = new Rectangle(position, TILE_W - 1, TILE_H - 1);
    regardeDroite = true;
    arme = null;
    imageWidth = TILE_W;
    imageHeight = TILE_H;
    imageX= 0;
  }
  
  public boolean checkCollision(Objet o)
  {
    return checkCollision(o.forme);
  }
  
  public boolean checkCollision(Forme f)
  {
    return f.collision(forme);
  }
  
  public void appliquerForce(PVector f)
  {
    if (est_mobile)
      acceleration.add(f);
  }
  
  public void traiterCollision(Objet o)
  {
    if (est_destructible && o.pv > 0)
      this.pv -= o.degats;
  }
  
  public void afficher()
  {
    if (animationSet == null)
      image(ressources.get("default"), position.x, position.y, TILE_W, TILE_H);
    else {
      
      if (arme != null && millis() - arme.lastAttaque < 500)
        animationSet.change(3);
      else if (abs(vitesse.x) < 0.01f)
        animationSet.change(0);
      else
        animationSet.change(1);
      
      pushMatrix();
      translate(position.x + imageWidth / 2 + imageX, 0);
      if (!regardeDroite)
        scale(-1, 1);
        
      image(animationSet.getFrame(), - imageWidth / 2, position.y, imageWidth, imageHeight);
      popMatrix();
    }
  }
  
  public void exploser()
  {
     Tileset exp = ressources.tileset("explosion");
     monde.animations.add(new AnimationRect(new Animation(exp, 0, exp.getTileX() * exp.getTileY() - 1, 100), (int) position.x, (int) position.y, 50, 50));

     Projectile obj = new Projectile(position, new PVector(), this);
     obj.forme = new Cercle(obj.position, 40);
     obj.pv = 100;
     
     Objet collider = monde.checkCollision(obj, this);
     int i = 0;
     while (collider != null && collider != monde.joueur && collider != monde.boss && i++ < 20)
     {
       if (collider.est_destructible) collider.pv = 0;
       obj.pv = 100;
       collider = monde.checkCollision(obj);
     }
     
     if (collider == monde.joueur) monde.joueur.pv -= degats;
     if (collider == monde.boss && monde.boss != null) monde.boss.pv -= degats;
      
  }
  
  public boolean isPerso()
  {
    return false;
  }
  
  public float distanceSq(Objet obj)
  {
    PVector a = forme.getCenter(), b = obj.forme.getCenter();
    return a.sub(b).magSq();
  }
  
  public void evoluer(float duree)
  {    
    for (int i = 0; i< 4; i++)
      objetsContact[i] = null;
    
    appliquerForce(PVector.mult(monde.gravite, duree));
    
    //On ajoute l'acceleraion a la vitesse
    vitesse.add(acceleration);
        
    //vitesse * duree = deplacement
    PVector deplacement = PVector.mult(vitesse, duree);
               
    //On essaye le mouvement en y
    float prevY = position.y;
    position.y += deplacement.y;
    
    Objet o = monde.checkCollision(this);
    if (o != null)
    {
      position.y = prevY;
      
      if (vitesse.y > 0)
        objetsContact[BAS] = o;
      else
        objetsContact[HAUT] = o;
      
      traiterCollision(o);
      o.traiterCollision(this);
      
      vitesse.y = 0;
    }
    
    //On essaye le mouvement en x
    float prevX = position.x;
    position.x += deplacement.x;

    o = monde.checkCollision(this);
    if (o != null)
    {
      position.x = prevX;
      
      if (vitesse.x > 0)
        objetsContact[DROITE] = o;
      else
        objetsContact[GAUCHE] = o;
      
      traiterCollision(o);
      o.traiterCollision(this);
    }

    vitesse.add(acceleration);
    
    //On reset l'acceleration
    acceleration.set(0, 0);
    
    //Friction
    vitesse.mult((float)0.999f); 
    
    if (vitesse.x < 0) regardeDroite = false;
    else if (vitesse.x > 0) regardeDroite = true;
  }
  
  public void sauter()
  {
    if (objetsContact[BAS] != null)
      vitesse.y = - 300;
  }
  public void tirer()
  {
    if (arme == null)
      return;
 
    arme.utiliser();
  }
  
   public boolean affecte(Objet o)
  {
    if (o instanceof Projectile)
      return o.affecte(this);
    
    return true;
  }
}
class Plateforme extends Objet {
  
  public int indice = 0;
  
  public Plateforme(int x, int y)
  {
    super(x * TILE_W, y * TILE_H, false, true, 30, 0); 
  }
  
  public void calculerAffichage()
  {
    int[] voisins = new int[4];
    for (int i = 0; i < voisins.length; i++)
    {
      if (i == 4) continue;
      int pos = i * 2 + 1;
      int dx = (pos % 3) - 1;
      int dy = 1 - (pos / 3);
      float x = position.x + TILE_W / 2  + TILE_W * dx, y = position.y + TILE_H / 2 + TILE_H * dy;
      
      Objet obj = new Objet((int) x, (int) y, false, false, 0, 0);
      obj.forme = new Point(obj.position);
      
      voisins[i] = monde.checkCollision(obj) instanceof Plateforme ? 1 : 0;
    }
    
    indice = 15 - (voisins[3] * 8 + voisins[1] * 4 + voisins[2] * 2 + voisins[0]);    
  }
  
  public void afficher()
  {
   if (!est_destructible)
      tint(150);
   image(ressources.tileset("terrain").get(indice), position.x, position.y, TILE_W, TILE_H);
   tint(255);
  }
  
   public void traiterCollision(Objet o)
  {
    if (!o.isPerso() && est_destructible)
      this.pv -= o.degats;
  }
}
public class Point extends Forme {
	
	PVector pos;
	
	//Attention : pas de suivi de x et y dans ce cas
	public Point(float x, float y)
	{
		this(new PVector(x, y));
	}
	
	public Point(PVector pos)
	{
		this.pos = pos;
	}
	
	@Override
	public PVector getCenter() {
		return pos.copy();
	}

	@Override
	public PVector getNearest(float x, float y) {
		return getCenter();
	}

	public @Override
	boolean collision(Rectangle r) {
		return r.collision(this);
	}

	public @Override
	boolean collision(Cercle c) {
		return c.collision(c);
	}

	public @Override
	boolean collision(Point p) {
		return pos.equals(p.pos);
	}

	@Override
	public Forme getTranslation(PVector dir) {
		return new Point(getCenter());
	}

}
class Projectile extends Objet {
  
  public Objet tireur;
  public float distance;
  public boolean gravite;
  
  public Projectile(PVector pos, PVector vitesse, Objet tireur)
  {
    super((int) pos.x, (int) pos.y);
    this.vitesse = vitesse;
    this.tireur = tireur;
    this.degats = 25;
    forme = new Cercle(position, 5);
    distance = 500;
    gravite = false;
  }
  
  public void traiterCollision(Objet o)
  {
     this.pv = 0;
     if (o.est_destructible)
       o.pv -= degats;
     degats = 0;
  }
  
  public void evoluer(float duree)
  { 
    PVector oldPos = new PVector(position.x, position.y);
    if (!gravite) appliquerForce(PVector.mult(monde.gravite, -duree));
    super.evoluer(duree);
    distance -= oldPos.sub(position).mag();
    if (distance < 0)
      pv = 0;
  }
  
  public void afficher()
  {
    image(tireur == monde.joueur ? ressources.get("flechette") : ressources.get("tir"), position.x - 5, position.y - 5, 10, 10);
  }
  
  public boolean affecte(Objet o)
  {
    if (tireur == o)
      return false;
    if (tireur != monde.joueur && o.isPerso() && o != monde.joueur)
      return false;
    if (o instanceof Projectile)
      return this.affecte(((Projectile) o).tireur);
      
    return true;
  }
}

class Grenade extends Projectile {
  
  public Grenade(PVector pos, PVector vitesse, Objet tireur)
  {
    super(pos, vitesse, tireur);
    this.degats = 20;
    forme = new Cercle(position, 12);
    distance= 2500;
    gravite = true;
  }
  
  public void traiterCollision(Objet o)
  {
     this.pv = 0;
     if (o.est_destructible)
       o.pv -= degats;
     exploser();
  }
  
  public void afficher()
  {
    pushMatrix();
    translate(position.x - 12, position.y - 12);
    
    rotate(millis() / 300.0f);
    
    image(ressources.get("erlenmeier"),  0, 0, 24, 24);
    popMatrix();
  }
}
class Range implements Iterable<Integer>{

  public int deb, fin, inc;
  
  public Range(String desc) {
     inc = 1;
     if (desc.contains(":"))
     {
       String[] range = desc.split(":");
       deb = Integer.parseInt(range[0]);
       if (range[1].contains(";"))
       {
          range = range[1].split(";");
          fin = Integer.parseInt(range[0]);
          inc = Integer.parseInt(range[1]);
       }
       else 
         fin = Integer.parseInt(range[1]);
     }
     else
       deb = fin = Integer.parseInt(desc);
       
  }
  
  public Iterator<Integer> iterator() {
    return new Iterator<Integer>() {
      int value = deb;
      public Integer next(){
        int v = value;
        value += inc;
        return v;
      }
      public boolean hasNext() {
        return value <= fin;
      }
    };
  }

}


public class Rectangle extends Forme {
	
	 PVector pos;
	 float w, h;
	
	public Rectangle(PVector p, float w, float h)
	{
		pos = p;
		this.w = w;
		this.h= h;
	}

	public @Override
	boolean collision(Rectangle r) {
		return (pos.x + w >= r.pos.x &&
				pos.x <= r.pos.x + r.w &&
				pos.y + h >= r.pos.y &&
				pos.y <= r.pos.y + r.h);
	}

	public @Override
	boolean collision(Cercle c) {
		return c.collision(this);
	}

	public @Override
	boolean collision(Point p) {
		return 	p.pos.x >= pos.x &&
				p.pos.x <= pos.x + w &&
				p.pos.y >= pos.y &&
				p.pos.y <= pos.y + h;
	}
	
	public String toString()
	{
		return pos.x+";"+pos.y+" "+w+";"+h;
	}

	@Override
	public PVector getCenter() {
		return PVector.add(pos, new PVector(w/2, h/2));
	}
	
	@Override
	public PVector getNearest(float x, float y) {
		PVector vec = new PVector();
		if (x >= pos.x + w)
		{
			vec.x = pos.x + w;
			vec.y = constrain(y, pos.y, pos.y + h);
		}
		else if (x <= pos.x)
		{
			vec.x = pos.x;
			vec.y = constrain(y, pos.y, pos.y + h);
		}
		else if (y <= pos.y)
		{
			vec.x = constrain(x, pos.x, pos.x + w);
			vec.y = pos.y;
		}
		else if (y >= pos.y + h)
		{
			vec.x = constrain(x, pos.x, pos.x + w);
			vec.y = pos.y + h;
		}
		else
			vec = PVector.add(pos, new PVector(w / 2, h / 2));
		
		return vec;
	}

	@Override
	public Forme getTranslation(PVector dir) {
		return new Rectangle(PVector.add(dir, pos), w, h);
	}
	
	

}
class Tileset{
 private int w,h,wTile,hTile;
  private ArrayList<PImage> images=null;
 
 Tileset(PImage img, int nbX, int nbY)
  {
    	w=nbX;
    	h=nbY;
    	wTile=img.width/w;
    	hTile=img.height/h;
      images=new ArrayList<PImage>();
      for (int y=0;y<nbY;y++)
      {
        for (int x=0;x<nbX;x++)
          images.add(img.get(x*wTile,y*hTile,wTile,hTile));
      }
  }

  public PImage get(int index)
  {
    if (images==null)
      return null;
  	return images.get(index);
  }
  
  
  public int getTileX()
  {
    return w;
  }
  
  public int getTileY()
  {
    return h;
  }
  public int getTileW()
  {
    return wTile;
  }
  
  public int getTileH()
  {
    return hTile;
  }
}
class Vue {
  
  private PVector positionVue;
  public PVector following;
  public int w, h, mondeW, mondeH;
  
  public Vue(PVector f, int w, int h, int mondeW, int mondeH)
  {
    this.w = w;
    this.h = h;
    this.mondeW = mondeW;
    this.mondeH = mondeH;
    following = f;
    positionVue = new PVector(0, 0);
  }
  
  public PVector mondeVersVue(PVector pos)
  {
    return PVector.sub(pos, getPosVuePixels());
  }
  
  public PVector vueVersMonde(PVector pos)
  {
    return PVector.add(pos, getPosVuePixels());
  }
  
  public boolean estDansVue(PVector pos)
  {
    return estDansVue(new Point(pos));
  }
  
  public boolean estDansVue(Objet o)
  {
    return estDansVue(o.forme);
  }
  
  public boolean estDansVue(Forme f)
  {
    Forme r = new Rectangle(getPosVuePixels(), w * TILE_W, h * TILE_H);
    return r.collision(f);
  }
  
  public PVector getPosVue()
  {
    return positionVue;    
  }
  
  public PVector getPosVuePixels()
  {
    return PVector.mult(getPosVue(), TILE_W);
  }
  
  public void actualiser() 
  {
    positionVue.x = constrain(following.x / TILE_W - w / 2, 0, (mondeW - w));
    positionVue.y = constrain(following.y / TILE_H - h / 2, 0, (mondeH - h));
  }
  
}
  public void settings() {  size(640, 480); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "SuperTeemoBros" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
